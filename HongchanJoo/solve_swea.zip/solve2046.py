def solve2046():
    t = int(input())
    for _ in range(t - 1):
        print('#',end='')
    print('#')    

if __name__ == "__main__":
    solve2046()