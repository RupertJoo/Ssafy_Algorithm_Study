def solve2050():
    string = list(input())
    print(*map(lambda x: ord(x) - 64,string))
    return 
    

if __name__ == "__main__":
    solve2050()